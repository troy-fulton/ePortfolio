I included TCxUC, SDBP, and DIP-Global in case they are useful when interpreting my paper.
They should compile just the same as the ones in the root directory, although they are not 
meant to be graded.