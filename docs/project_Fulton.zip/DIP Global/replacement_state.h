#ifndef REPL_STATE_H
#define REPL_STATE_H
 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This file is distributed as part of the Cache Replacement Championship     //
// workshop held in conjunction with ISCA'2010.                               //
//                                                                            //
//                                                                            //
// Everyone is granted permission to copy, modify, and/or re-distribute       //
// this software.                                                             //
//                                                                            //
// Please contact Aamer Jaleel <ajaleel@gmail.com> should you have any        //
// questions                                                                  //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include <cassert>
#include "utils.h"
#include "crc_cache_defs.h"
#include <iostream>

#define L1_CAPACITY	(64 * 1024)
#define L1_BLOCKSIZE	64
#define L1_ASSOC	4
#define L1_NSETS	(L1_CAPACITY/(L1_BLOCKSIZE*L1_ASSOC))

// L2 shared cache: 256KB

#define L2_CAPACITY	(256 * 1024)
#define L2_BLOCKSIZE	64
#define L2_ASSOC	8
#define L2_NSETS	(L2_CAPACITY/(L2_BLOCKSIZE*L2_ASSOC))

// L3 shared cache: 4MB

#ifndef LLC_CAPACITY
#define LLC_CAPACITY	(4 * 1024 * 1024)
#endif
#define LLC_BLOCKSIZE	64
#define LLC_ASSOC	16
#define LLC_NSETS	(LLC_CAPACITY/(LLC_BLOCKSIZE*LLC_ASSOC))

using namespace std;

#define DEBUG_DUELER  0

typedef enum 
{
    L1_CACHE = 1,
    L2_CACHE = 2,
    L3_CACHE = 3
} Cache;

// Replacement State Per Cache Line
typedef struct
{
    UINT32  LRUstackposition;

    // CONTESTANTS: Add extra state per cache line here
	bool valid;
	Addr_t block_addr;

	void init() {
		valid = false;
		block_addr = 0;
	}

} LINE_REPLACEMENT_STATE;

struct MY_CACHE {
	LINE_REPLACEMENT_STATE** MY_L1;
	LINE_REPLACEMENT_STATE** MY_L2;
	LINE_REPLACEMENT_STATE** MY_L3;

	LINE_REPLACEMENT_STATE l2wb_buf, l3wb_buf;
	LINE_REPLACEMENT_STATE* L1_line;		// where the new block was inserted

	bool HIT;
	bool MISS;
	int L1_assoc, L2_assoc, L3_assoc;
	float epsilon;

	MY_CACHE();
	~MY_CACHE();
	
	bool Access( Addr_t block_address, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid );

	bool Access_L1( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid );
	bool Access_L2( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid );
	bool Access_L3( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid );

	int search_set(LINE_REPLACEMENT_STATE* repl, int assoc, Addr_t block_addr);
	void copy_line(LINE_REPLACEMENT_STATE* new_line, LINE_REPLACEMENT_STATE* old_line);

	virtual int Choose_L1_Victim(LINE_REPLACEMENT_STATE* replSet);
	virtual int Choose_L2_Victim(LINE_REPLACEMENT_STATE* replSet);
	virtual int Choose_L3_Victim(LINE_REPLACEMENT_STATE* replSet);

	virtual void Update_L1(LINE_REPLACEMENT_STATE* replSet, int updateWayID);
	virtual void Update_L2(LINE_REPLACEMENT_STATE* replSet, int updateWayID);
	virtual void Update_L3(LINE_REPLACEMENT_STATE* replSet, int updateWayID);

};

struct LRU_CACHE : public MY_CACHE {
	virtual int Choose_L1_Victim(LINE_REPLACEMENT_STATE* replSet);
	virtual int Choose_L2_Victim(LINE_REPLACEMENT_STATE* replSet);
	virtual int Choose_L3_Victim(LINE_REPLACEMENT_STATE* replSet);

	virtual void Update_L1(LINE_REPLACEMENT_STATE* replSet, int updateWayID);
	virtual void Update_L2(LINE_REPLACEMENT_STATE* replSet, int updateWayID);
	virtual void Update_L3(LINE_REPLACEMENT_STATE* replSet, int updateWayID);
};

// Replacement Policies Supported
typedef enum 
{
    CRC_REPL_LRU        = 0,
    CRC_REPL_RANDOM     = 1,
    CRC_REPL_CONTESTANT = 2
} ReplacemntPolicy;

struct sampler; // Jimenez's structures

// The implementation for the cache replacement policy
class CACHE_REPLACEMENT_STATE
{
public:
    LINE_REPLACEMENT_STATE   **repl;
    LINE_REPLACEMENT_STATE   **LRU_repl;
    LINE_REPLACEMENT_STATE   **MY_repl;
  private:

    UINT32 numsets;
    UINT32 assoc;
    UINT32 replPolicy;

    COUNTER mytimer;  // tracks # of references to the cache

    // CONTESTANTS:  Add extra state for cache here
	int PSEL;
	int n_bits, sat_val;
	bool curr_policy;
	bool MY_policy;
	bool LRU_policy;

	float epsilon;

  public:
    ostream & PrintStats(ostream &out);

    // The constructor CAN NOT be changed
    CACHE_REPLACEMENT_STATE( UINT32 _sets, UINT32 _assoc, UINT32 _pol );

    INT32 GetVictimInSet( UINT32 tid, UINT32 setIndex, const LINE_STATE *vicSet, UINT32 assoc, Addr_t PC, Addr_t paddr, UINT32 accessType, UINT32 accessSource);

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID);

    void   SetReplacementPolicy( UINT32 _pol ) { replPolicy = _pol; } 
    void   IncrementTimer() { mytimer++; } 

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID, const LINE_STATE *currLine, 
                                   UINT32 tid, Addr_t PC, UINT32 accessType, bool cacheHit, UINT32 accessSource);

    ~CACHE_REPLACEMENT_STATE(void);

  private:
    
    void   InitReplacementState();
    INT32  Get_Random_Victim( UINT32 setIndex );

    INT32  Get_LRU_Victim( UINT32 setIndex );
    INT32  Get_My_Victim( UINT32 setIndex );
    void   UpdateLRU( UINT32 setIndex, INT32 updateWayID );
    void   UpdateMyPolicy( UINT32 setIndex, INT32 updateWayID );
};

#endif
