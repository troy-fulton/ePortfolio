#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/mman.h>
#include <map>
#include <iostream>

using namespace std;

#include "replacement_state.h"

MY_CACHE my_cache;
LRU_CACHE lru_cache;

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This file is distributed as part of the Cache Replacement Championship     //
// workshop held in conjunction with ISCA'2010.                               //
//                                                                            //
//                                                                            //
// Everyone is granted permission to copy, modify, and/or re-distribute       //
// this software.                                                             //
//                                                                            //
// Please contact Aamer Jaleel <ajaleel@gmail.com> should you have any        //
// questions                                                                  //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*
** This file implements the cache replacement state. Users can enhance the code
** below to develop their cache replacement ideas.
**
*/

int LRU_CACHE::Choose_L1_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L1_assoc; way++) {
		if (replSet[way].LRUstackposition == (L1_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}
int LRU_CACHE::Choose_L2_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L2_assoc; way++) {
		if (replSet[way].LRUstackposition == (L2_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}
int LRU_CACHE::Choose_L3_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L3_assoc; way++) {
		if (replSet[way].LRUstackposition == (L3_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}

void LRU_CACHE::Update_L1(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	for(UINT32 way=0; way<L1_assoc; way++) {
		if( replSet[way].LRUstackposition < currLRUstackposition ) {
			replSet[way].LRUstackposition++;
		}
	}

	// Set the LRU stack position of new line to be zero
	replSet[ updateWayID ].LRUstackposition = 0;
}
void LRU_CACHE::Update_L2(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	for(UINT32 way=0; way<L2_assoc; way++) {
		if( replSet[way].LRUstackposition < currLRUstackposition ) {
			replSet[way].LRUstackposition++;
		}
	}

	// Set the LRU stack position of new line to be zero
	replSet[ updateWayID ].LRUstackposition = 0;
}
void LRU_CACHE::Update_L3(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	for(UINT32 way=0; way<L3_assoc; way++) {
		if( replSet[way].LRUstackposition < currLRUstackposition ) {
			replSet[way].LRUstackposition++;
		}
	}

	// Set the LRU stack position of new line to be zero
	replSet[ updateWayID ].LRUstackposition = 0;
}


MY_CACHE::MY_CACHE() : HIT(true), MISS(false), L1_assoc(4), L2_assoc(8), L3_assoc(16)
{
    epsilon = (1.0/32.0);
    MY_L1  = new LINE_REPLACEMENT_STATE* [ L1_NSETS ];
    MY_L2  = new LINE_REPLACEMENT_STATE* [ L2_NSETS ];
    MY_L3  = new LINE_REPLACEMENT_STATE* [ LLC_NSETS ];

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<L1_NSETS; setIndex++) 
    {
        MY_L1[ setIndex ]  = new LINE_REPLACEMENT_STATE[ L1_assoc ];

        for(UINT32 way=0; way<L1_assoc; way++) 
        {
            // initialize stack position (for true LRU)
            MY_L1[ setIndex ][ way ].LRUstackposition = way;
        }
    }

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<L2_NSETS; setIndex++) 
    {
        MY_L2[ setIndex ]  = new LINE_REPLACEMENT_STATE[ L2_assoc ];

        for(UINT32 way=0; way<L2_assoc; way++) 
        {
            // initialize stack position (for true LRU)
            MY_L2[ setIndex ][ way ].LRUstackposition = way;
        }
    }

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<LLC_NSETS; setIndex++) 
    {
        MY_L3[ setIndex ]  = new LINE_REPLACEMENT_STATE[ L3_assoc ];

        for(UINT32 way=0; way<L3_assoc; way++) 
        {
            // initialize stack position (for true LRU)
            MY_L3[ setIndex ][ way ].LRUstackposition = way;
        }
    }
}

MY_CACHE::~MY_CACHE()
{
    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<L1_NSETS; setIndex++) 
    {
        delete[] MY_L1[ setIndex ];
    }

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<L2_NSETS; setIndex++) 
    {
        delete[] MY_L2[ setIndex ];
    }

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<LLC_NSETS; setIndex++) 
    {
        delete[] MY_L3[ setIndex ];
    }

    delete[] MY_L1;
    delete[] MY_L2;
    delete[] MY_L3;

}

bool MY_CACHE::Access( Addr_t block_addr, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid )
{
	if (accessType == ACCESS_PREFETCH)
		return -1;
	Addr_t L1_set = block_addr & 0xFF;
	Addr_t L2_set = block_addr & 0x01FF;
	Addr_t L3_set = block_addr & 0x0FFF;

	// Mostly modeled from cache.cc (memory_access()):

	bool missL1 = false;
	bool missL2 = false;
	bool missL3 = false;

	missL1 = Access_L1 (block_addr, L1_set, PC, accessType, accessSource, tid);
    if (missL1) {
		// see if the block is in the L2, but don't place it there if not
		missL2 = Access_L2 (block_addr, L2_set, PC, accessType, accessSource, tid);
		if (missL2) {
			// see if the block is in the shared LLC, but don't place it there if not
			missL3 = Access_L3 (block_addr, L3_set, PC, accessType, accessSource, tid);
		}
		if (l2wb_buf.valid)
			Access_L2 (block_addr, L2_set, PC, accessType, accessSource, tid);

		if (l3wb_buf.valid)
			Access_L3 (block_addr, L3_set, PC, accessType, accessSource, tid);
	}
	return missL1 | missL2 | missL3;
	
}

int MY_CACHE::search_set(LINE_REPLACEMENT_STATE* repl, int assoc, Addr_t block_addr)
{
	for (int way = 0; way < assoc; way++) {
		if (repl[way].block_addr == block_addr)
			return way;
	}
	return -1;
}

bool MY_CACHE::Access_L1( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid )
{
	int way = search_set(MY_L1[setIndex], L1_assoc, block_addr);

	if (way == -1) {
		way = Choose_L1_Victim(MY_L1[setIndex]);
		L1_line = &MY_L1[setIndex][way];
		if (MY_L1[setIndex][way].valid == true)
			copy_line(&l2wb_buf, &MY_L1[setIndex][way]);
		
		MY_L1[setIndex][way].init();
		MY_L1[setIndex][way].valid = true;
		MY_L1[setIndex][way].block_addr = block_addr;
		Update_L1(MY_L1[setIndex], way);
		return MISS;
	}
	
	return HIT;
}

bool MY_CACHE::Access_L2( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid )
{
	bool cacheHit = false;
	int way = search_set(MY_L2[setIndex], setIndex, block_addr);
	if (way >= 0)
		cacheHit = true;

	if (cacheHit) {
		copy_line(L1_line, &MY_L2[setIndex][way]);
	}

	if (l2wb_buf.valid) {
		way = Choose_L2_Victim(MY_L2[setIndex]);
		if (MY_L2[setIndex][way].valid) {
			copy_line(&l3wb_buf, &MY_L2[setIndex][way]);
		}
		copy_line(&MY_L2[setIndex][way], &l2wb_buf);
		Update_L2(MY_L2[setIndex], way);
		return cacheHit;
	}
	else {
		return MISS;
	}
}

bool MY_CACHE::Access_L3( Addr_t block_addr, UINT32 setIndex, Addr_t PC, UINT32 accessType, UINT32 accessSource, UINT32 tid )
{
	bool cacheHit = false;
	int way = search_set(MY_L3[setIndex], setIndex, block_addr);
	if (way >= 0)
		cacheHit = true;

	if (cacheHit) {
		copy_line(L1_line, &MY_L3[setIndex][way]);
	}

	if (l3wb_buf.valid) {
		way = Choose_L3_Victim(MY_L3[setIndex]);
		copy_line(&MY_L3[setIndex][way], &l3wb_buf);
		Update_L3(MY_L3[setIndex], way);
		return cacheHit;
	}
	else {
		return MISS;
	}
}


void MY_CACHE::copy_line(LINE_REPLACEMENT_STATE* new_line, LINE_REPLACEMENT_STATE* old_line)
{
	new_line->valid = true;
	new_line->block_addr = old_line->block_addr;

	old_line->valid = false;
}

int MY_CACHE::Choose_L1_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L1_assoc; way++) {
		if (replSet[way].LRUstackposition == (L1_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}

int MY_CACHE::Choose_L2_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L2_assoc; way++) {
		if (replSet[way].LRUstackposition == (L2_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}

int MY_CACHE::Choose_L3_Victim(LINE_REPLACEMENT_STATE* replSet)
{
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(INT32 way=0; way<L3_assoc; way++) {
		if (replSet[way].LRUstackposition == (L3_assoc-1)) {
			lruWay = way;
			break;
		}
		else if (!replSet[way].valid)
			return way;
	}

	// return lru way
	return lruWay;
}

void MY_CACHE::Update_L1(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	float num = (float) rand() / RAND_MAX;

	epsilon = 1.0/4.0;

	if (num < epsilon) {
		// put in MRU position
		for(UINT32 way=0; way<L1_assoc; way++) {
			if( replSet[way].LRUstackposition > currLRUstackposition ) {
				replSet[way].LRUstackposition--;
			}
		}

		// Set the LRU stack position of new line to be LRU
		replSet[ updateWayID ].LRUstackposition = (L1_assoc - 1);
	
	} else {
		// otherwise, do LRU like normal
		for(UINT32 way=0; way<L1_assoc; way++) {
			if( replSet[way].LRUstackposition < currLRUstackposition ) {
				replSet[way].LRUstackposition++;
			}
		}

		// Set the LRU stack position of new line to be zero
		replSet[ updateWayID ].LRUstackposition = 0;
	}
}

void MY_CACHE::Update_L2(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	float num = (float) rand() / RAND_MAX;

	epsilon = 1.0/8.0;

	if (num < epsilon) {
		// put in MRU position
		for(UINT32 way=0; way<L2_assoc; way++) {
			if( replSet[way].LRUstackposition > currLRUstackposition ) {
				replSet[way].LRUstackposition--;
			}
		}

		// Set the LRU stack position of new line to be LRU
		replSet[ updateWayID ].LRUstackposition = (L2_assoc - 1);
	
	} else {
		// otherwise, do LRU like normal
		for(UINT32 way=0; way<L2_assoc; way++) {
			if( replSet[way].LRUstackposition < currLRUstackposition ) {
				replSet[way].LRUstackposition++;
			}
		}

		// Set the LRU stack position of new line to be zero
		replSet[ updateWayID ].LRUstackposition = 0;
	}
}

void MY_CACHE::Update_L3(LINE_REPLACEMENT_STATE* replSet, int updateWayID)
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = replSet[ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	float num = (float) rand() / RAND_MAX;

	epsilon = 1.0/16.0;

	if (num < epsilon) {
		// put in MRU position
		for(UINT32 way=0; way<L3_assoc; way++) {
			if( replSet[way].LRUstackposition > currLRUstackposition ) {
				replSet[way].LRUstackposition--;
			}
		}

		// Set the LRU stack position of new line to be LRU
		replSet[ updateWayID ].LRUstackposition = (L3_assoc - 1);
	
	} else {
		// otherwise, do LRU like normal
		for(UINT32 way=0; way<L3_assoc; way++) {
			if( replSet[way].LRUstackposition < currLRUstackposition ) {
				replSet[way].LRUstackposition++;
			}
		}

		// Set the LRU stack position of new line to be zero
		replSet[ updateWayID ].LRUstackposition = 0;
	}
}


////////////////////////////////////////////////////////////////////////////////
// The replacement state constructor:                                         //
// Inputs: number of sets, associativity, and replacement policy to use       //
// Outputs: None                                                              //
//                                                                            //
// DO NOT CHANGE THE CONSTRUCTOR PROTOTYPE                                    //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
CACHE_REPLACEMENT_STATE::CACHE_REPLACEMENT_STATE( UINT32 _sets, UINT32 _assoc, UINT32 _pol )
{

    numsets    = _sets;
    assoc      = _assoc;
    replPolicy = _pol;

    mytimer    = 0;

    InitReplacementState();
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// The function prints the statistics for the cache                           //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
ostream & CACHE_REPLACEMENT_STATE::PrintStats(ostream &out)
{

    out<<"=========================================================="<<endl;
    out<<"=========== Replacement Policy Statistics ================"<<endl;
    out<<"=========================================================="<<endl;


    // CONTESTANTS:  Insert your statistics printing here
    
    return out;

}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function initializes the replacement policy hardware by creating      //
// storage for the replacement state on a per-line/per-cache basis.           //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void CACHE_REPLACEMENT_STATE::InitReplacementState()
{
    // Create the state for sets, then create the state for the ways

    repl  = new LINE_REPLACEMENT_STATE* [ numsets ];
    LRU_repl  = new LINE_REPLACEMENT_STATE* [ numsets ];
    MY_repl  = new LINE_REPLACEMENT_STATE* [ numsets ];

    // ensure that we were able to create replacement state

    assert(repl);

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<numsets; setIndex++) 
    {
        repl[ setIndex ]  = new LINE_REPLACEMENT_STATE[ assoc ];
        LRU_repl[ setIndex ]  = new LINE_REPLACEMENT_STATE[ assoc ];
        MY_repl[ setIndex ]  = new LINE_REPLACEMENT_STATE[ assoc ];

        for(UINT32 way=0; way<assoc; way++) 
        {
            // initialize stack position (for true LRU)
            repl[ setIndex ][ way ].LRUstackposition = way;
            LRU_repl[ setIndex ][ way ].LRUstackposition = way;
            MY_repl[ setIndex ][ way ].LRUstackposition = way;
            MY_repl[ setIndex ][ way ].valid = false;
        }
    }

    if (replPolicy != CRC_REPL_CONTESTANT) return;

    // Contestants:  ADD INITIALIZATION FOR YOUR HARDWARE HERE
	MY_policy = true;
	LRU_policy = false;
	PSEL = 0;
	n_bits = 2;
	sat_val = (1 << n_bits) - 1;
    epsilon = (1.0/8.0);
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function is called by the cache on every cache miss. The input        //
// argument is the set index. The return value is the physical way            //
// index for the line being replaced.                                         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::GetVictimInSet( UINT32 tid, UINT32 setIndex, const LINE_STATE *vicSet, UINT32 assoc, Addr_t PC, Addr_t paddr, UINT32 accessType, UINT32 accessSource ) {
    // If no invalid lines, then replace based on replacement policy
    if( replPolicy == CRC_REPL_LRU ) 
    {
        return Get_LRU_Victim( setIndex );
    }
    else if( replPolicy == CRC_REPL_RANDOM )
    {
        return Get_Random_Victim( setIndex );
    }
    else if( replPolicy == CRC_REPL_CONTESTANT )
    {
        // Contestants:  ADD YOUR VICTIM SELECTION FUNCTION HERE
        if (accessType == ACCESS_PREFETCH)
			return -1;
        
        if (curr_policy == MY_policy)
			return Get_My_Victim(setIndex);
		else
			return Get_LRU_Victim(setIndex);
    }

    // We should never here here

    assert(0);
    return -1;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function is called by the cache after every cache hit/miss            //
// The arguments are: the set index, the physical way of the cache,           //
// the pointer to the physical line (should contestants need access           //
// to information of the line filled or hit upon), the thread id              //
// of the request, the PC of the request, the accesstype, and finall          //
// whether the line was a cachehit or not (cacheHit=true implies hit)         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
void CACHE_REPLACEMENT_STATE::UpdateReplacementState( 
    UINT32 setIndex, INT32 updateWayID, const LINE_STATE *currLine, 
    UINT32 tid, Addr_t PC, UINT32 accessType, bool cacheHit, UINT32 accessSource )
{
    // What replacement policy?
    if( replPolicy == CRC_REPL_LRU ) 
    {
        UpdateLRU( setIndex, updateWayID );
    }
    else if( replPolicy == CRC_REPL_RANDOM )
    {
        // Random replacement requires no replacement state update
    }
    else if( replPolicy == CRC_REPL_CONTESTANT )
    {
        // Contestants:  ADD YOUR UPDATE REPLACEMENT STATE FUNCTION HERE
        // Feel free to use any of the input parameters to make
        // updates to your replacement policiy

		bool mine_would_hit;
		bool lru_would_hit;

		Addr_t block_addr;

		if (accessSource == 1) {
			block_addr = (currLine->tag << 8) | setIndex;
			mine_would_hit = my_cache.Access(block_addr, PC, accessType, accessSource, tid);
			lru_would_hit = lru_cache.Access(block_addr, PC, accessType, accessSource, tid);
			if (!mine_would_hit && PSEL < sat_val) {
				PSEL++;
			}
			if (!lru_would_hit && PSEL > 0) {
				PSEL--;
			}
		}

		if (PSEL >> (n_bits - 1)) {
			curr_policy = LRU_policy;
		}
		else {
			curr_policy = MY_policy;
		}


		if (curr_policy == MY_policy)
			UpdateLRU(setIndex, updateWayID);
		else
			UpdateMyPolicy(setIndex, updateWayID);
    }
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//////// HELPER FUNCTIONS FOR REPLACEMENT UPDATE AND VICTIM SELECTION //////////
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function finds the LRU victim in the cache set by returning the       //
// cache block at the bottom of the LRU stack. Top of LRU stack is '0'        //
// while bottom of LRU stack is 'assoc-1'                                     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::Get_LRU_Victim( UINT32 setIndex )
{
	// Get pointer to replacement state of current set

	LINE_REPLACEMENT_STATE *replSet = repl[ setIndex ];
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(UINT32 way=0; way<assoc; way++) {
		if (replSet[way].LRUstackposition == (assoc-1)) {
			lruWay = way;
			break;
		}
	}

	// return lru way
	return lruWay;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function finds a random victim in the cache set                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::Get_Random_Victim( UINT32 setIndex )
{
    INT32 way = (rand() % assoc);
    
    return way;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function implements the LRU update routine for the traditional        //
// LRU replacement policy. The arguments to the function are the physical     //
// way and set index.                                                         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void CACHE_REPLACEMENT_STATE::UpdateLRU( UINT32 setIndex, INT32 updateWayID )
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = repl[ setIndex ][ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	for(UINT32 way=0; way<assoc; way++) {
		if( repl[setIndex][way].LRUstackposition < currLRUstackposition ) {
			repl[setIndex][way].LRUstackposition++;
		}
	}

	// Set the LRU stack position of new line to be zero
	repl[ setIndex ][ updateWayID ].LRUstackposition = 0;
}

INT32 CACHE_REPLACEMENT_STATE::Get_My_Victim( UINT32 setIndex ) {
	return Get_LRU_Victim(setIndex);
}

void CACHE_REPLACEMENT_STATE::UpdateMyPolicy( UINT32 setIndex, INT32 updateWayID ) {
	// Determine current LRU stack position
	UINT32 currLRUstackposition = repl[ setIndex ][ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	float num = (float) rand() / RAND_MAX;

	if (assoc == 4)
		epsilon = 1.0/4.0;
	if (assoc == 8)
		epsilon = 1.0/8.0;
	if (assoc == 16)
		epsilon = 1.0/16.0;

	if (num < epsilon) {
		// put in MRU position
		for(UINT32 way=0; way<assoc; way++) {
			if( repl[setIndex][way].LRUstackposition > currLRUstackposition ) {
				repl[setIndex][way].LRUstackposition--;
			}
		}

		// Set the LRU stack position of new line to be LRU
		repl[setIndex][ updateWayID ].LRUstackposition = (assoc - 1);
	
	} else {
		// otherwise, do LRU like normal
		for(UINT32 way=0; way<assoc; way++) {
			if( repl[setIndex][way].LRUstackposition < currLRUstackposition ) {
				repl[setIndex][way].LRUstackposition++;
			}
		}

		// Set the LRU stack position of new line to be zero
		repl[setIndex][ updateWayID ].LRUstackposition = 0;
	}
	// Do nothing...
}

CACHE_REPLACEMENT_STATE::~CACHE_REPLACEMENT_STATE (void) {
}
