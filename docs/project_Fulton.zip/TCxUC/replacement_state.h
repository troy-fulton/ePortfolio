#ifndef REPL_STATE_H
#define REPL_STATE_H
 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This file is distributed as part of the Cache Replacement Championship     //
// workshop held in conjunction with ISCA'2010.                               //
//                                                                            //
//                                                                            //
// Everyone is granted permission to copy, modify, and/or re-distribute       //
// this software.                                                             //
//                                                                            //
// Please contact Aamer Jaleel <ajaleel@gmail.com> should you have any        //
// questions                                                                  //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include <cassert>
#include "utils.h"
#include "crc_cache_defs.h"
#include <iostream>
#include <map>
#include <vector>
#include <algorithm>
#include <math.h>

#define ACCESS_1		1	// first access to L1
#define ACCESS_2		2	// access to L2 on L1 miss
#define ACCESS_3		3	// access to L3 on L2 miss
#define ACCESS_4		4	// writeback to L2 on eviction from L1
#define ACCESS_5		5	// writeback to L3 on eviction from L2
#define ACCESS_6		6	// second writeback to L3 on eviction from L2

#define MAX_TC 7
#define MAX_UC 7

using namespace std;

#define DEBUG_DUELER  0

struct SetDueler {
	unsigned int n_bits, sat_val;		// how many bits PSEL is
	// For policies A and B, name the min and max sets
	int A_min_set, A_max_set;
	int B_min_set, B_max_set;

	// TRUE: Policy A
	// FALSE: Policy B
	bool policy;

	unsigned int PSEL;

	SetDueler(int n, int num_observers) :
		n_bits(n), A_min_set(0), A_max_set(0),
		B_min_set(0), B_max_set(0), PSEL(0)
	{
		A_min_set = 1000;
		A_max_set = A_min_set + num_observers - 1;
		
		B_min_set = A_max_set + 1;
		B_max_set = B_min_set + num_observers - 1;
		
		sat_val = (1 << n_bits) - 1;
	}

	void policy_A_miss() {
		if (PSEL < sat_val)
			PSEL++;
		// Get the MSB
#if DEBUG_DUELER
		bool prev_policy = policy;
#endif
		policy = PSEL >> (n_bits - 1) == 1;
#if DEBUG_DUELER
		if (policy != prev_policy) {
			cout << "Switching from Policy " << ((policy == 0) ? "A" : "B") << " to ";
			cout << ((policy == 1) ? "A" : "B") << endl;
		}
#endif
	}
	
	void policy_B_miss() {
		if (PSEL > 0)
			PSEL--;
		// Get the MSB
#if DEBUG_DUELER
		bool prev_policy = policy;
#endif
		policy = PSEL >> (n_bits - 1) == 0;
#if DEBUG_DUELER
		if (policy != prev_policy) {
			cout << "Switching from Policy " << ((policy == 0) ? "A" : "B") << " to ";
			cout << ((policy == 1) ? "A" : "B") << endl;
		}
#endif
	}

	void miss(int set) {
		if (A_min_set <= set && set <= A_max_set) {
			policy_A_miss();
		}
		else if (B_min_set <= set && set <= B_max_set) {
			policy_B_miss();
		}
	}

	bool which_policy(int set) {
		if (A_min_set <= set && set <= A_max_set)
			return true;
		else if (B_min_set <= set && set <= B_max_set)
			return false;
		else
			return policy;
	}
};

typedef unsigned int TCxUC;

// Replacement Policies Supported
typedef enum 
{
    CRC_REPL_LRU        = 0,
    CRC_REPL_RANDOM     = 1,
    CRC_REPL_CONTESTANT = 2
} ReplacemntPolicy;

// Replacement State Per Cache Line
typedef struct
{
    UINT32  LRUstackposition;

    // CONTESTANTS: Add extra state per cache line here
    int L2TC;
	int L3TC;
    bool fromL2;
    bool fromL3;
	int UC;
	bool valid;

	int age;
	TCxUC bin;

	Addr_t block_addr;

} LINE_REPLACEMENT_STATE;

struct sampler; // Jimenez's structures

struct Bin {
	int D_L;
	int L;

	Bin() : D_L(0), L(0) {}
};

struct SampleGuesser {
	int assoc;
	map<TCxUC, Bin> bins;

	int maxD_L, minD_L, maxL, minL, aggD_L;
	int allocations_count;
	int N;

	int num_observers;
	vector<int> observer_sets;

	bool use_bypass;

	int bypassing_start, bypassing_end;
	int nonbypassing_start, nonbypassing_end;

	SampleGuesser(int n_observers, int associativity, bool bypass)
	{
		assoc = associativity;
		num_observers = n_observers;
		maxD_L = 0;
		minD_L = 0;
		maxL = 0;
		minL = 0;
		aggD_L = 0;
		allocations_count = 0;
		N = n_observers * assoc;
		use_bypass = bypass;

		bypassing_start = 0;
		bypassing_end   = n_observers;
		nonbypassing_start = bypassing_end;
		nonbypassing_end   = nonbypassing_start + n_observers;
		int start, end;
		if (bypass) {
			start = bypassing_start;
			end = bypassing_end;
		}
		else {
			start = nonbypassing_start;
			end = nonbypassing_end;
		}
		
		for (int i = start; i < end; i++)
		{
			observer_sets.push_back(i);
		}
	}

	TCxUC hash(LINE_REPLACEMENT_STATE* repl)
	{
		TCxUC tcuc = repl->UC | (repl->L2TC << 8);
		return tcuc;
	}

	bool is_observer(int setIndex)
	{
		return find(observer_sets.begin(), observer_sets.end(), setIndex) != observer_sets.end();
	}

	void L3_Hit(int setIndex, LINE_REPLACEMENT_STATE* repl)
	{
		// Check we have a sample set
		if (!is_observer(setIndex))
			return;

		// Hash first then update the bin 
		TCxUC hash_key = hash(repl);
		Bin& bin = bins[hash_key];

		bin.D_L -= 2;
		bin.L++;
		if (repl->UC > 0) {
			if (bin.D_L > maxD_L) maxD_L = bin.D_L;
			if (bin.D_L < minD_L) minD_L = bin.D_L;
			if (bin.L > maxL) maxL = bin.L;
			if (bin.L < minL) minL = bin.L;
			aggD_L += bin.D_L;
		}
	}

	void L3_Allocation(int setIndex, LINE_REPLACEMENT_STATE* repl)
	{
		allocations_count++;
		if (allocations_count == N) {
			allocations_count = 0;
			map<TCxUC, Bin>::iterator it = bins.begin();
			while (it != bins.end()) {
				it->second.D_L = it->second.D_L / 2;
				it->second.L = it->second.L / 2;
				it++;
			}
			maxD_L /= 2;
			minD_L /= 2;
			maxL /= 2;
			minL /= 2;
			aggD_L /= 2;
		}

		// Check we have a sample set
		if (!is_observer(setIndex))
			return;

		// Hash first then update the bin 
		TCxUC hash_key = hash(repl);
		Bin& bin = bins[hash_key];

		bin.D_L++;
		if (repl->UC > 0) {
			if (bin.D_L > maxD_L) maxD_L = bin.D_L;
			if (bin.D_L < minD_L) minD_L = bin.D_L;
			if (bin.L > maxL) maxL = bin.L;
			if (bin.L < minL) minL = bin.L;
			aggD_L += bin.D_L;
		}
	}

	int insertion_age(LINE_REPLACEMENT_STATE* repl)
	{
		return (repl->L3TC > 0) ? 3 : 1;
	}

	bool bypass(LINE_REPLACEMENT_STATE* repl)
	{
		if (use_bypass) {
			TCxUC hash_key = hash(repl);
			Bin& bin = bins[hash_key];

			float first_term = (float) 0.5 * ((float) maxD_L + minD_L);
			float second_term = (float) 0.5 * ((float) maxL + minL);
			float third_term = (float) 0.75 * ((float) aggD_L);
			return (bin.D_L >= first_term && bin.L <= second_term) || bin.D_L >= third_term;
		}
		else
			return false;
	}
};

// The implementation for the cache replacement policy
class CACHE_REPLACEMENT_STATE
{
public:
    LINE_REPLACEMENT_STATE   **repl;
  private:

    UINT32 numsets;
    UINT32 assoc;
    UINT32 replPolicy;

    COUNTER mytimer;  // tracks # of references to the cache

    // CONTESTANTS:  Add extra state for cache here

  public:
    ostream & PrintStats(ostream &out);

    // The constructor CAN NOT be changed
    CACHE_REPLACEMENT_STATE( UINT32 _sets, UINT32 _assoc, UINT32 _pol );

    INT32 GetVictimInSet( UINT32 tid, UINT32 setIndex, const LINE_STATE *vicSet, UINT32 assoc, Addr_t PC, Addr_t paddr, UINT32 accessType, UINT32 accessSource);

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID);

    void   SetReplacementPolicy( UINT32 _pol ) { replPolicy = _pol; } 
    void   IncrementTimer() { mytimer++; } 

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID, const LINE_STATE *currLine, 
                                   UINT32 tid, Addr_t PC, UINT32 accessType, bool cacheHit, UINT32 accessSource);

    ~CACHE_REPLACEMENT_STATE(void);

  private:
    
    void   InitReplacementState();
    INT32  Get_Random_Victim( UINT32 setIndex );

    INT32  Get_LRU_Victim( UINT32 setIndex );
    INT32  Get_My_Victim( UINT32 setIndex, bool bypass );
    void   UpdateLRU( UINT32 setIndex, INT32 updateWayID );
    void   UpdateMyPolicy( UINT32 setIndex, INT32 updateWayID );
};

#endif
