#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>
#include <sys/mman.h>
#include <map>
#include <iostream>

using namespace std;

#include "replacement_state.h"

#define NUM_SDBP_SAMPLES 16
#define NUM_LRU_SAMPLES  NUM_SDBP_SAMPLES //16

SetDueler dueler(2, NUM_SDBP_SAMPLES);	// n-bit dueler with m observers
										// Samples: A: 100 - num_observers
										// 			B: 0   - num_observers
DeadBlockSampler sampler(NUM_SDBP_SAMPLES, 15);	// n-set m-bit

LINE_REPLACEMENT_STATE l2wb_buffer;
LINE_REPLACEMENT_STATE l3wb_buffer;

void copy_repl(LINE_REPLACEMENT_STATE* new_repl, LINE_REPLACEMENT_STATE* old_repl)
{
	//new_repl.LRUstackposition = old_repl.LRUstackposition;
	// Just need to keep the signature and prediction
	new_repl->Signature = old_repl->Signature;
	new_repl->prediction = old_repl->prediction;
	new_repl->block_addr = old_repl->block_addr;
}

////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This file is distributed as part of the Cache Replacement Championship     //
// workshop held in conjunction with ISCA'2010.                               //
//                                                                            //
//                                                                            //
// Everyone is granted permission to copy, modify, and/or re-distribute       //
// this software.                                                             //
//                                                                            //
// Please contact Aamer Jaleel <ajaleel@gmail.com> should you have any        //
// questions                                                                  //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

/*
** This file implements the cache replacement state. Users can enhance the code
** below to develop their cache replacement ideas.
**
*/


////////////////////////////////////////////////////////////////////////////////
// The replacement state constructor:                                         //
// Inputs: number of sets, associativity, and replacement policy to use       //
// Outputs: None                                                              //
//                                                                            //
// DO NOT CHANGE THE CONSTRUCTOR PROTOTYPE                                    //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
CACHE_REPLACEMENT_STATE::CACHE_REPLACEMENT_STATE( UINT32 _sets, UINT32 _assoc, UINT32 _pol )
{

    numsets    = _sets;
    assoc      = _assoc;
    replPolicy = _pol;

    mytimer    = 0;

    InitReplacementState();
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// The function prints the statistics for the cache                           //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
ostream & CACHE_REPLACEMENT_STATE::PrintStats(ostream &out)
{

    out<<"=========================================================="<<endl;
    out<<"=========== Replacement Policy Statistics ================"<<endl;
    out<<"=========================================================="<<endl;

    // CONTESTANTS:  Insert your statistics printing here
    
    return out;

}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function initializes the replacement policy hardware by creating      //
// storage for the replacement state on a per-line/per-cache basis.           //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void CACHE_REPLACEMENT_STATE::InitReplacementState()
{
    // Create the state for sets, then create the state for the ways

    repl  = new LINE_REPLACEMENT_STATE* [ numsets ];

    // ensure that we were able to create replacement state

    assert(repl);

    // Create the state for the sets
    for(UINT32 setIndex=0; setIndex<numsets; setIndex++) 
    {
        repl[ setIndex ]  = new LINE_REPLACEMENT_STATE[ assoc ];

        for(UINT32 way=0; way<assoc; way++) 
        {
            // initialize stack position (for true LRU)
            repl[ setIndex ][ way ].LRUstackposition = way;
            repl[ setIndex ][ way ].valid = false;
            repl[ setIndex ][ way ].prediction = sampler.LIVE;
            repl[ setIndex ][ way ].block_addr = 0;
        }
    }

    if (replPolicy != CRC_REPL_CONTESTANT) return;

    // Contestants:  ADD INITIALIZATION FOR YOUR HARDWARE HERE
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function is called by the cache on every cache miss. The input        //
// argument is the set index. The return value is the physical way            //
// index for the line being replaced.                                         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::GetVictimInSet( UINT32 tid, UINT32 setIndex, const LINE_STATE *vicSet, UINT32 assoc, Addr_t PC, Addr_t paddr, UINT32 accessType, UINT32 accessSource ) {
    // If no invalid lines, then replace based on replacement policy
    if( replPolicy == CRC_REPL_LRU ) 
    {
        return Get_LRU_Victim( setIndex );
    }
    else if( replPolicy == CRC_REPL_RANDOM )
    {
        return Get_Random_Victim( setIndex );
    }
    else if( replPolicy == CRC_REPL_CONTESTANT )
    {
		if (assoc < 16)
			return Get_LRU_Victim(setIndex);

		if (accessType == ACCESS_PREFETCH)
			return -1;
        // Contestants:  ADD YOUR VICTIM SELECTION FUNCTION HERE
       
		//bool policy = dueler.which_policy(setIndex);
		//if (policy)	// LRU
		//	return Get_LRU_Victim(setIndex);
		//else {
			//return Get_Random_Victim(setIndex);	
			//return Get_My_Victim(setIndex, &l3wb_buffer, true);
		//} 
		return Get_My_Victim(setIndex, &l3wb_buffer, true);
    }

    // We should never here here

    assert(0);
    return -1;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function is called by the cache after every cache hit/miss            //
// The arguments are: the set index, the physical way of the cache,           //
// the pointer to the physical line (should contestants need access           //
// to information of the line filled or hit upon), the thread id              //
// of the request, the PC of the request, the accesstype, and finall          //
// whether the line was a cachehit or not (cacheHit=true implies hit)         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
void CACHE_REPLACEMENT_STATE::UpdateReplacementState( 
    UINT32 setIndex, INT32 updateWayID, const LINE_STATE *currLine, 
    UINT32 tid, Addr_t PC, UINT32 accessType, bool cacheHit, UINT32 accessSource )
{
	// Update the dueler
	if (assoc == 16 && !cacheHit)
		dueler.miss(setIndex);

	Addr_t curr_block_addr = currLine->tag;

	if (assoc == 4)
		curr_block_addr = (curr_block_addr << 8) | setIndex;
	if (assoc == 8)
		curr_block_addr = (curr_block_addr << 9) | setIndex;
	if (assoc == 16)
		curr_block_addr = (curr_block_addr << 12) | setIndex;

    LINE_REPLACEMENT_STATE* curr_repl = &repl[ setIndex ][ updateWayID ];

	unsigned int curr_signature = (unsigned int) PC & 0x7FFF;	// lower 15 bits

	switch (accessSource) {
	case ACCESS_1:	// First access to L1
		if (!curr_repl->valid) {
			curr_repl->valid = true;
#if DEBUG_SAMPLER
			cout << "L1 block " << hex << curr_block_addr << " inserted" << endl;
#endif
		}
		else {
			// Store the signature into L2 WB for later
			copy_repl(&l2wb_buffer, curr_repl);
#if DEBUG_SAMPLER
			cout << "L1 block " << hex << curr_repl->block_addr << " evicted" << endl;
			cout << "New block " << hex << curr_block_addr << " replaced it" << endl;
#endif
		}
		
		// When inserting into cache or on hits, note the PC
		curr_repl->Signature = curr_signature;
		// Predict if this signature will be dead:
		curr_repl->prediction = sampler.predict(curr_signature, accessType == ACCESS_PREFETCH);
		curr_repl->block_addr = curr_block_addr;
		
		break;
	case ACCESS_2:	// First access to L2
	case ACCESS_3:	// First access to L3
		if (cacheHit) {
			curr_repl->valid = false;
			if (accessSource == ACCESS_3) {	// On L3 CACHE hits
				sampler.hit(setIndex, curr_repl->Signature);
#if DEBUG_SAMPLER
				cout << "L3 Hit block " << hex << curr_repl->block_addr << " with sig " << curr_repl->Signature << endl;
#endif
			}
			if (accessSource == ACCESS_2) {
#if DEBUG_SAMPLER
				cout << "L2 Hit block " << hex << curr_repl->block_addr << endl;
#endif
			}
		}
		break;
	case ACCESS_4:	// WB to L2
		// Save the block currently there
		if (curr_repl->valid) {
			copy_repl(&l3wb_buffer, curr_repl);
#if DEBUG_SAMPLER
			cout << "L2 block " << hex << curr_repl->block_addr << " evicted " << endl;
			cout << "L1 block " << hex << curr_block_addr << " replaced it" << endl;
#endif
		}
		else {
			curr_repl->valid = true;
#if DEBUG_SAMPLER
			cout << "L2 block " << hex << curr_block_addr << " inserted" << endl;
#endif
		}
#if DEBUG_SAMPLER
		cout << "l2wb_buffer has block " << hex << l2wb_buffer.block_addr << endl;
#endif
		// Consume the wb buffer
		copy_repl(curr_repl, &l2wb_buffer);
		break;
	case ACCESS_5:	// WB to L3
	case ACCESS_6:	// WB to L3 again
		if (curr_repl->valid) {
			sampler.evict(setIndex, curr_repl->Signature);
#if DEBUG_SAMPLER
			cout << "L3 block " << hex << curr_repl->block_addr << " evicted " << endl;
			cout << "L2 block " << hex << curr_block_addr << " replaced it" << endl;
#endif
		}
		else {
			curr_repl->valid = true;
#if DEBUG_SAMPLER
			cout << "L3 block " << hex << curr_block_addr << " inserted" << endl;
#endif
		}
#if DEBUG_SAMPLER
		cout << "l3wb_buffer has block " << hex << l3wb_buffer.block_addr << endl;
#endif
		copy_repl(curr_repl, &l3wb_buffer);
		break;
	default:
		break;
	}

    // What replacement policy?
    if( replPolicy == CRC_REPL_LRU ) 
    {
        UpdateLRU( setIndex, updateWayID );
    }
    else if( replPolicy == CRC_REPL_RANDOM )
    {
        // Random replacement requires no replacement state update
    }
    else if( replPolicy == CRC_REPL_CONTESTANT )
    {
        UpdateLRU( setIndex, updateWayID );
        // Contestants:  ADD YOUR UPDATE REPLACEMENT STATE FUNCTION HERE
        // Feel free to use any of the input parameters to make
        // updates to your replacement policy
    }
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
//////// HELPER FUNCTIONS FOR REPLACEMENT UPDATE AND VICTIM SELECTION //////////
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function finds the LRU victim in the cache set by returning the       //
// cache block at the bottom of the LRU stack. Top of LRU stack is '0'        //
// while bottom of LRU stack is 'assoc-1'                                     //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::Get_LRU_Victim( UINT32 setIndex )
{
	// Get pointer to replacement state of current set

	LINE_REPLACEMENT_STATE *replSet = repl[ setIndex ];
	INT32   lruWay   = 0;

	// Search for victim whose stack position is assoc-1

	for(UINT32 way=0; way<assoc; way++) {
		if (replSet[way].LRUstackposition == (assoc-1)) {
			lruWay = way;
			break;
		}
	}

	// return lru way

	return lruWay;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function finds a random victim in the cache set                       //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////
INT32 CACHE_REPLACEMENT_STATE::Get_Random_Victim( UINT32 setIndex )
{
    INT32 way = (rand() % assoc);
    
    return way;
}

////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This function implements the LRU update routine for the traditional        //
// LRU replacement policy. The arguments to the function are the physical     //
// way and set index.                                                         //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

void CACHE_REPLACEMENT_STATE::UpdateLRU( UINT32 setIndex, INT32 updateWayID )
{
	// Determine current LRU stack position
	UINT32 currLRUstackposition = repl[ setIndex ][ updateWayID ].LRUstackposition;

	// Update the stack position of all lines before the current line
	// Update implies incremeting their stack positions by one

	for(UINT32 way=0; way<assoc; way++) {
		if( repl[setIndex][way].LRUstackposition < currLRUstackposition ) {
			repl[setIndex][way].LRUstackposition++;
		}
	}

	// Set the LRU stack position of new line to be zero
	repl[ setIndex ][ updateWayID ].LRUstackposition = 0;
}

INT32 CACHE_REPLACEMENT_STATE::Get_My_Victim( UINT32 setIndex, LINE_REPLACEMENT_STATE* curr_repl, bool use_bypass ) {
	// Bypass policy:
	if (use_bypass) {
		if (curr_repl->prediction == sampler.DEAD) {
			return -1;
		}
	}

	for (unsigned int way = 0; way < assoc; way++) {
		if (repl[setIndex][way].prediction == sampler.DEAD) {
#if DEBUG_SAMPLER
			cout << "Set " << setIndex << " way " << way << " predicted dead" << endl;
#endif
			return way;
		}
	}

#if DEBUG_SAMPLER
	cout << "Set " << setIndex << " using LRU..." << endl;
#endif
	// If all else fails, use LRU
	return Get_LRU_Victim(setIndex);
}

void CACHE_REPLACEMENT_STATE::UpdateMyPolicy( UINT32 setIndex, INT32 updateWayID ) {
	// do nothing
}

CACHE_REPLACEMENT_STATE::~CACHE_REPLACEMENT_STATE (void) {
}
