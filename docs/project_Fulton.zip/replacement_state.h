#ifndef REPL_STATE_H
#define REPL_STATE_H
 
////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////
//                                                                            //
// This file is distributed as part of the Cache Replacement Championship     //
// workshop held in conjunction with ISCA'2010.                               //
//                                                                            //
//                                                                            //
// Everyone is granted permission to copy, modify, and/or re-distribute       //
// this software.                                                             //
//                                                                            //
// Please contact Aamer Jaleel <ajaleel@gmail.com> should you have any        //
// questions                                                                  //
//                                                                            //
////////////////////////////////////////////////////////////////////////////////

#include <cstdlib>
#include <cassert>
#include "utils.h"
#include "crc_cache_defs.h"
#include <iostream>
#include <map>

using namespace std;

#define MAX_TC 3
#define MAX_UC 3

#define ACCESS_1		1	// first access to L1
#define ACCESS_2		2	// access to L2 on L1 miss
#define ACCESS_3		3	// access to L3 on L2 miss
#define ACCESS_4		4	// writeback to L2 on eviction from L1
#define ACCESS_5		5	// writeback to L3 on eviction from L2
#define ACCESS_6		6	// second writeback to L3 on eviction from L2

// Replacement Policies Supported
typedef enum 
{
    CRC_REPL_LRU        = 0,
    CRC_REPL_RANDOM     = 1,
    CRC_REPL_CONTESTANT = 2
} ReplacemntPolicy;

struct Dueler {
	int policy_A_min, policy_A_max;
	int policy_B_min, policy_B_max;

	unsigned int PSEL;
	int n_bits;
	int sat_val;

	Dueler(int num_observers) {
		policy_A_min = 0;
		policy_A_max = num_observers - 1;
		policy_B_min = num_observers;
		policy_B_max = 2*num_observers - 1;

		n_bits = 11;
		sat_val = (1 << n_bits) - 1;

		PSEL = 0;
	}

	bool is_A_observer(int setIndex) {
		return (policy_A_min <= setIndex && setIndex <= policy_A_max);
	}

	bool is_B_observer(int setIndex) {
		return (policy_B_min <= setIndex && setIndex <= policy_B_max);
	}
};

typedef unsigned int TCxUC;

// Replacement State Per Cache Line
typedef struct
{
    UINT32  LRUstackposition;

    // CONTESTANTS: Add extra state per cache line here
    int L2TC;
	int L3TC;
    bool fromL2;
    bool fromL3;
	int UC;
	bool valid;

	int age;
	TCxUC bin;

	Addr_t block_addr;

} LINE_REPLACEMENT_STATE;

void copy_repl(LINE_REPLACEMENT_STATE* new_repl, LINE_REPLACEMENT_STATE* old_repl);

struct sampler; // Jimenez's structures

typedef int TripCount;
typedef int UseCount;

struct Histogram {
	std::map<TripCount, int> L2TCbins;
	std::map<TripCount, int> L3TCbins;
	std::map<UseCount, int>  UCbins;
	std::map<int, int>   	 L2TCxUCbins;
	std::map<int, int>   	 L3TCxUCbins;
	std::map<int, int>		 L2TCxL3TCbins;
	
	void Print() {
		std::map<TripCount, int>::iterator iter;
		cout << "L2TC" << endl;
		for (iter = L2TCbins.begin(); iter != L2TCbins.end(); iter++) {
			cout << iter->first << "," << iter->second << endl;
		}
		cout << "L3TC" << endl;
		for (iter = L3TCbins.begin(); iter != L3TCbins.end(); iter++) {
			cout << iter->first << "," << iter->second << endl;
		}
		cout << "UC" << endl;
		for (iter = UCbins.begin(); iter != UCbins.end(); iter++) {
			cout << iter->first << "," << iter->second << endl;
		}

		cout << "L2TCxUC" << endl;
		for (iter = L2TCxUCbins.begin(); iter != L2TCxUCbins.end(); iter++) {
			cout << (iter->first >> 8) << "," << (iter->first & 0xFF) << "," << iter->second << endl;
		}
		cout << "L3TCxUC" << endl;
		for (iter = L3TCxUCbins.begin(); iter != L3TCxUCbins.end(); iter++) {
			cout << (iter->first >> 8) << "," << (iter->first & 0xFF) << "," << iter->second << endl;
		}
		cout << "L2TCxL3TC" << endl;
		for (iter = L2TCxL3TCbins.begin(); iter != L2TCxL3TCbins.end(); iter++) {
			cout << (iter->first >> 8) << "," << (iter->first & 0xFF) << "," << iter->second << endl;
		}
	}

	int hash(int a, int b) {
		return (a << 8) | b;
	}

	void L2TC_insert(TripCount tc) {
		L2TCbins[tc]++;
	}
	void L3TC_insert(TripCount tc) {
		L3TCbins[tc]++;
	}
	void UC_insert(UseCount uc) {
		UCbins[uc]++;
	}

	void L2TCxUC_insert(TripCount l2tc, UseCount uc) {
		int hash_val = hash(l2tc, uc);
		L2TCxUCbins[hash_val]++;
	}
	void L3TCxUC_insert(TripCount l3tc, UseCount uc) {
		int hash_val = hash(l3tc, uc);
		L3TCxUCbins[hash_val]++;
	}
	void L2TCxL3TC_insert(TripCount l2tc, TripCount l3tc) {
		int hash_val = hash(l2tc, l3tc);
		L2TCxL3TCbins[hash_val]++;
	}

	void insert(LINE_REPLACEMENT_STATE* block) {
		assert(block);
		L2TC_insert(block->L2TC);
		L3TC_insert(block->L3TC);
		UC_insert(block->UC);

		L2TCxUC_insert(block->L2TC, block->UC);
		L3TCxUC_insert(block->L3TC, block->UC);
		L2TCxL3TC_insert(block->L2TC, block->L3TC);
	}
};

// The implementation for the cache replacement policy
class CACHE_REPLACEMENT_STATE
{
public:
    LINE_REPLACEMENT_STATE   **repl;
  private:

    UINT32 numsets;
    UINT32 assoc;
    UINT32 replPolicy;

    COUNTER mytimer;  // tracks # of references to the cache

    // CONTESTANTS:  Add extra state for cache here
    float epsilon;

  public:
    ostream & PrintStats(ostream &out);

    // The constructor CAN NOT be changed
    CACHE_REPLACEMENT_STATE( UINT32 _sets, UINT32 _assoc, UINT32 _pol );

    INT32 GetVictimInSet( UINT32 tid, UINT32 setIndex, const LINE_STATE *vicSet, UINT32 assoc, Addr_t PC, Addr_t paddr, UINT32 accessType, UINT32 accessSource);

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID);

    void   SetReplacementPolicy( UINT32 _pol ) { replPolicy = _pol; } 
    void   IncrementTimer() { mytimer++; } 

    void   UpdateReplacementState( UINT32 setIndex, INT32 updateWayID, const LINE_STATE *currLine, 
                                   UINT32 tid, Addr_t PC, UINT32 accessType, bool cacheHit, UINT32 accessSource);

    ~CACHE_REPLACEMENT_STATE(void);

  private:
    
    void   InitReplacementState();
    INT32  Get_Random_Victim( UINT32 setIndex );

    INT32  Get_LRU_Victim( UINT32 setIndex );
    INT32  Get_My_Victim( UINT32 setIndex );
    void   UpdateLRU( UINT32 setIndex, INT32 updateWayID );
    void   UpdateMyPolicy( UINT32 setIndex, INT32 updateWayID );
};

#endif
